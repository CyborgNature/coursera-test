# logistic-reg
This repo contains a jupyter notebook with a logistic regression implementation from scratch using NumPy.

https://medium.com/@martinpella/logistic-regression-from-scratch-in-python-124c5636b8ac
